<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Proyecto SOFWARE-sensores')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="flex">
        <!-- Menú Lateral -->
        <aside class="user-option-title">
            <?php if(Auth::user()->role === 'admin'): ?>
                <!-- Botón Principal: Opciones de Administrador -->
                <h3>
                    <button 
                        class="user-option-title w-full text-left px-4 py-2 bg-blue-500 text-white font-semibold rounded"
                        onclick="toggleMenu('admin-options')">
                        <?php echo e(__('Opciones de Administrador')); ?>

                    </button>
                </h3>

                <!-- Opciones de Administrador -->
                <ul id="admin-options" class="hidden space-y-4 pl-4 mt-4" style="list-style: none;">
                    <!-- Gestión de Usuarios -->
                    <li style="list-style: none;">
                        <button 
                            class="user-option-item w-full text-left px-4 py-2 bg-blue-400 hover:bg-blue-500 text-white rounded"
                            onclick="toggleMenu('user-management')">
                            <?php echo e(__('Gestión de Usuarios')); ?>

                        </button>
                        <ul id="user-management" class="hidden space-y-1 pl-6" style="list-style: none;">
                            <li style="list-style: none;">
                                <a href="<?php echo e(route('admin.list-users')); ?>" class="user-option-sub block text-left">
                                    <?php echo e(__('-Lista de Usuarios')); ?>

                                </a>
                            </li>
                            <li style="list-style: none;">
                                <a href="<?php echo e(route('admin.create-user')); ?>" class="user-option-sub block text-left">
                                    <?php echo e(__('-Agregar Usuario')); ?>

                                </a>
                            </li>
                        </ul>
                    </li>

                    <!-- Gestión de Sensores -->
                    <li style="list-style: none;">
                        <button 
                            class="user-option-item w-full text-left px-4 py-2 bg-blue-400 hover:bg-blue-500 text-white rounded" 
                            onclick="toggleMenu('sensor-management')">
                            <?php echo e(__('Gestión de Sensores')); ?>

                        </button>
                        <ul id="sensor-management" class="hidden space-y-1 pl-6" style="list-style: none;">
                            <li style="list-style: none;">
                                <a href="<?php echo e(route('admin.sensors.create')); ?>" class="user-option-sub block text-left">
                                    <?php echo e(__('-Agregar Sensores')); ?>

                                </a>
                            </li>
                            <li style="list-style: none;">
                                <a href="<?php echo e(route('admin.sensors.index')); ?>" class="user-option-sub block text-left">
                                    <?php echo e(__('-Lista de Sensores')); ?>

                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>

                <!-- Opciones de Usuario -->
                <li style="list-style: none;">
                    <button 
                        class="user-option-title w-full text-left px-4 py-2 bg-green-500 hover:bg-green-600 text-white font-semibold rounded mt-4"
                        onclick="toggleMenu('user-options')">
                        <?php echo e(__('Opciones de Usuario')); ?>

                    </button>
                    <ul id="user-options" class="hidden user-option-item w-full hidden space-y-1 pl-6 mt-2" style="list-style: none;">
                        <li style="list-style: none;">
                            <a href="<?php echo e(route('sensors.list')); ?>" 
                               class="block text-center  bg-blue-400 hover:bg-blue-500 text-white rounded">
                                <?php echo e(__('-Ver Sensores')); ?>

                            </a>
                        </li>
                    </ul>
                </li>
            <?php else: ?>
                <!-- Opciones de Usuario -->
                <li style="list-style: none;">
                    <button 
                        class="user-option-title w-full text-left px-4 py-2 bg-green-500 hover:bg-green-600 text-white font-semibold rounded mt-4"
                        onclick="toggleMenu('user-options')">
                        <?php echo e(__('Opciones de Usuario')); ?>

                    </button>
                    <ul id="user-options" class=" hidden user-option-item space-y-1 pl-6 mt-2" style="list-style: none;">
                        <li style="list-style: none;">
                            <a href="<?php echo e(route('sensors.list')); ?>" 
                               class="block text-center  bg-blue-400 hover:bg-blue-500 text-white rounded">
                                <?php echo e(__('-Ver Sensores')); ?>

                            </a>
                        </li>
                    </ul>
                </li>
            <?php endif; ?>
        </aside>

        <!-- Contenido Principal -->
        <main class="flex-1 p-6 bg-gray-100 dark:bg-gray-900">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-6 text-white">
                <h3 class="font-semibold text-xl text-white">
                    <?php if(Auth::user()->role === 'admin'): ?>
                        <?php echo e(__('Bienvenido Administrador')); ?>

                    <?php else: ?>
                        <?php echo e(__('Bienvenido Usuario')); ?>

                    <?php endif; ?>
                </h3>
                <p class="mt-2"><?php echo e(__('Selecciona una opción del menú para continuar.')); ?></p>
            </div>
        </main>
    </div>

    <script>
        function toggleMenu(id) {
            const menu = document.getElementById(id);
            menu.classList.toggle('hidden');
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\programas\SOFWARE\XAMP\Programa\htdocs\prueba1\resources\views/dashboard.blade.php ENDPATH**/ ?>