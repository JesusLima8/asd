<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Editar Usuario')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="form-container">
            <form method="POST" action="<?php echo e(route('admin.update-user', $user->id)); ?>" class="space-y-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Campo Nombre -->
                <div>
                    <label for="name" class="form-label">Nombre:</label>
                    <input type="text" name="name" id="name" value="<?php echo e($user->name); ?>" class="form-input" required>
                </div>

                <!-- Campo Email -->
                <div>
                    <label for="email" class="form-label">Email:</label>
                    <input type="email" name="email" id="email" value="<?php echo e($user->email); ?>" class="form-input" required>
                </div>

                <!-- Campo Contraseña -->
                <div>
                    <label for="password" class="form-label">Contraseña (dejar en blanco si no desea cambiarla):</label>
                    <input type="password" name="password" id="password" class="form-input">
                </div>

                <!-- Campo Rol -->
                <div>
                    <label for="role" class="form-label">Rol:</label>
                    <select name="role" id="role" class="form-input" required>
                        <option value="user" <?php echo e($user->role === 'user' ? 'selected' : ''); ?>>Usuario</option>
                        <option value="admin" <?php echo e($user->role === 'admin' ? 'selected' : ''); ?>>Administrador</option>
                    </select>
                </div>

                <!-- Botón de Actualizar -->
                <div class="flex justify-end">
                    <button type="submit" class="btn-submit">Actualizar Usuario</button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\programas\SOFWARE\XAMP\Programa\htdocs\prueba1\resources\views/admin/edit-user.blade.php ENDPATH**/ ?>