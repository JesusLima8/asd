<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Seleccionar Ubicación')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-6">
                <h1 class="text-lg font-bold mb-4">Seleccionar Ubicación</h1>
                <p class="mb-4">Arrastra el marcador para obtener la latitud y longitud:</p>
                <div id="map" class="w-full h-96 rounded-md shadow-md"></div>
                <div class="mt-4 flex space-x-4">
                    <div>
                        <label for="latitude" class="block text-base font-medium">Latitud:</label>
                        <input type="text" id="latitude" readonly class="mt-1 block w-full border-gray-300 rounded-md shadow-sm text-black">
                    </div>
                    <div>
                        <label for="longitude" class="block text-base font-medium">Longitud:</label>
                        <input type="text" id="longitude" readonly class="mt-1 block w-full border-gray-300 rounded-md shadow-sm text-black">
                    </div>
                </div>
                <button id="saveLocation" class="mt-6 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                    Guardar y Volver
                </button>
            </div>
        </div>
    </div>

    <script>
        function initMap() {
            const defaultLocation = { lat: -16.4066, lng: -71.5374 }; // Arequipa, UNSA
            const map = new google.maps.Map(document.getElementById("map"), {
                zoom: 15,
                center: defaultLocation,
            });

            const marker = new google.maps.Marker({
                position: defaultLocation,
                map: map,
                draggable: true,
            });

            // Actualiza los campos de latitud y longitud al mover el marcador
            marker.addListener("dragend", (event) => {
                document.getElementById("latitude").value = event.latLng.lat();
                document.getElementById("longitude").value = event.latLng.lng();
            });

            // Permite que un clic en el mapa mueva el marcador
            map.addListener("click", (event) => {
                marker.setPosition(event.latLng);
                document.getElementById("latitude").value = event.latLng.lat();
                document.getElementById("longitude").value = event.latLng.lng();
            });

            // Configurar latitud y longitud inicial
            document.getElementById("latitude").value = defaultLocation.lat;
            document.getElementById("longitude").value = defaultLocation.lng;
        }

        // Guardar coordenadas en localStorage y redirigir al formulario de creación
        document.getElementById("saveLocation").addEventListener("click", () => {
            const lat = document.getElementById("latitude").value;
            const lng = document.getElementById("longitude").value;

            if (lat && lng) {
                localStorage.setItem("selectedLatitude", lat);
                localStorage.setItem("selectedLongitude", lng);
                window.location.href = "<?php echo e(route('admin.sensors.create')); ?>"; // Ruta a la vista del formulario
            } else {
                alert("Por favor selecciona una ubicación antes de guardar.");
            }
        });
    </script>

    <!-- Cargar la API de Google Maps -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBol5qVgsckP561gyJ2ZmOwq4JOF4ZSKhA&callback=initMap" async defer></script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\programas\SOFWARE\XAMP\Programa\htdocs\prueba1\resources\views/admin/sensors/map_selector.blade.php ENDPATH**/ ?>